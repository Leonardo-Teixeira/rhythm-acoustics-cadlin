
library(ggplot2)



##
load("speech_activity_intervals.RData")

min_dur <- 1
targ_dur <- 2.5

step <- targ_dur/2

S <- INTS[INTS$type=="speech",]

t0 <- c()
t1 <- c()
for (i in (1:nrow(S))) {
  
  t0x <- S$t0[i]
  t1x <- S$t1[i]
  
  ons <- seq(from=t0x,to=t1x,by=step)
  
  if (length(ons)==1)
  {
    off <- min(ons + targ_dur,t1x)   

  } else {
    off <- c()
    for (j in (1:length(ons))){
      off[j] <- min(ons[j] + targ_dur,t1x) 
    }
    
  }

  t0 <- c(t0,ons)
  t1 <- c(t1,off)  
  
  
}

C <- data.frame(t0=t0,t1=t1,dur=t1-t0)

C <- C[C$dur>min_dur,]


save(C,file="chunk_info.RData")
