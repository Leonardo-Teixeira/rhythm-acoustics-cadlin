function [] = extract_env_metrics()


audioPath = ['.' filesep 'Audio' filesep];

addpath(genpath('M:\Data\repositories\EMD_amplitude_envelope'));

C = readtable('all_chunks_info.csv');

targ_Fs = 44100;

X = {}; Cixs=[];
for i=1:height(C)

    file = [audioPath C.file{i}];

    if ~exist(file,"file"), continue; end

    audinfo = audioinfo(file);

    ixs = round([C.t0(i) C.t1(i)]*audinfo.SampleRate);

    [x,Fs] = audioread(file,ixs);

    if Fs<targ_Fs
        x = resample(x,targ_Fs,Fs);
    end
    
    %t = (0:length(x)-1)/Fs;    
    %plot(t,x);
        
    X{end+1,1} = x;
    Cixs(end+1) = i;

end

par.Fs = targ_Fs;

M = envm_metrics_batch(X,par,'lowpass',10);

M = [C(Cixs,:) M];

save('chunk_metrics.mat',"M");
writetable(M,'chunk_metrics.csv');

end