# Load necessary libraries
library(seewave)
library(signal)

# Define the main folder path
main_folder <- "/Users/leonardoteixeira/Desktop/data"

# Function to extract the envelope with approximate resampling
extract_envelope <- function(file_path, new_Fs = 100) {
  # Load the audio signal
  wave <- readWave(file_path)
  Fs <- wave@samp.rate  # Original sampling frequency
  wave <- wave / (2^16 / 2 - 1)  # Normalize signal to be between -1 and 1
  
  # Calculate normalized cutoff frequencies, adapting to Fs
  nyquist <- Fs / 2
  low_cutoff <- max(80 / nyquist, 0.01)  # Set minimum cutoff to 0.01 to avoid errors
  high_cutoff <- min(10000 / nyquist, 0.99)  # Set maximum cutoff to 0.99 to avoid errors
  
  # Apply bandpass filter (adjusted for low Fs cases)
  bandpass_filter <- butter(4, c(low_cutoff, high_cutoff), type = "pass")
  filtered_signal <- filtfilt(bandpass_filter, wave@left)  # Apply filter
  
  # Get absolute values to obtain the envelope
  abs_signal <- abs(filtered_signal)
  
  # Apply lowpass filter to smooth the envelope (cutoff at 10 Hz or adjusted for low Fs)
  cutoff <- min(10 / nyquist, 0.99)  # Ensure lowpass cutoff is within valid range
  lowpass_filter <- butter(4, cutoff, type = "low")
  smoothed_signal <- filtfilt(lowpass_filter, abs_signal)
  
  # Final adjustments: make sure no negative values remain, normalize to max 1
  smoothed_signal[smoothed_signal < 0] <- 0
  smoothed_signal <- smoothed_signal / max(smoothed_signal)
  
  # Approximate resampling using interpolation
  original_time <- seq(0, length(smoothed_signal) - 1) / Fs
  new_time <- seq(0, max(original_time), by = 1 / new_Fs)
  resampled_signal <- approx(original_time, smoothed_signal, xout = new_time)$y
  
  return(resampled_signal)
}

# Initialize a loop to process each audio file within subfolders
envelope_data <- list()  # List to store each file's envelope data

# Identify all .wav files across subdirectories
subdirs <- list.files(main_folder, recursive = TRUE, full.names = TRUE, pattern = "\\.wav$")
for (file_path in subdirs) {
  # Extract the envelope for each file
  envelope <- extract_envelope(file_path)
  
  # Only store envelope if it was successfully processed
  if (!is.null(envelope)) {
    envelope_data[[file_path]] <- envelope  # Store the envelope with file name as key
    cat("Envelope extracted for:", file_path, "\n")  # Print confirmation message
  }
}
