# Load necessary libraries
library(ggplot2)

# Function to remove short intervals and merge consecutive ones of the same type
removeIntervals <- function(I, env_Fs) {
  if (nrow(I) > 1) {  # Only process if there is more than one row
    I <- I[!(I$remove),]
    
    lastSamp <- I$off[nrow(I)]
    
    # Remove consecutive intervals of the same type
    I$remove[2:nrow(I)] <- I$type[2:nrow(I)] == I$type[1:(nrow(I) - 1)]
    I <- I[!(I$remove),]
    
    # Adjust end times of intervals
    if (nrow(I) > 1) {  # Check again after filtering
      I$off[1:(nrow(I) - 1)] <- I$ons[2:nrow(I)]
    }
    
    I$off[nrow(I)] <- lastSamp
    I$dur_samp <- I$off - I$ons
    I$dur <- I$dur_samp / env_Fs
  }
  return(I)
}

# Set threshold and sampling rate for the envelopes
env_Fs <- 100
thresh <- 0.05
short_sil_tol <- 0.1
short_speech_tol <- 0.1

# List to store speech activity intervals for each file
all_intervals <- list()

# Loop through each envelope in 'envelope_data'
for (file_path in names(envelope_data)) {
  x <- envelope_data[[file_path]]
  
  # Detect activity changes in the signal based on the threshold
  dsx <- diff(sign(x - thresh))
  
  # Identify speech activity types and breaks
  satypes <- dsx[abs(dsx) == 2]
  sabreaks <- which(abs(dsx) == 2)
  
  ons <- c()
  off <- c()
  type <- c()
  
  # Loop through detected breaks to identify speech and silence intervals
  for (i in 1:(length(sabreaks) - 1)) {
    ons <- c(ons, sabreaks[i])
    off <- c(off, sabreaks[i + 1])
    type <- c(type, ifelse(satypes[i] > 0, "speech", "sil"))
  }
  
  # Create data frame for intervals
  INTS <- data.frame(type = type, ons = ons, off = off)
  
  # Calculate duration for each interval
  INTS$dur_samp <- INTS$off - INTS$ons
  INTS$dur <- INTS$dur_samp / env_Fs
  
  # Remove short silences and short speech intervals
  INTS$remove <- INTS$type == "sil" & INTS$dur < short_sil_tol
  INTS <- removeIntervals(INTS, env_Fs)
  
  INTS$remove <- INTS$type == "speech" & INTS$dur < short_speech_tol
  INTS <- removeIntervals(INTS, env_Fs)
  
  # Add time columns for visualization and file identifier
  INTS$t0 <- INTS$ons / env_Fs
  INTS$t1 <- INTS$off / env_Fs
  INTS$file <- basename(file_path)
  
  # Append intervals for this file to the main list
  all_intervals[[file_path]] <- INTS
  
  # Optional: plot for each file to visualize intervals
  ENV <- data.frame(env = x, t = seq(from = 0, to = (length(x) - 1)) / env_Fs)
  ggplot(data = ENV, aes(x = t, y = env)) +
    geom_line() +
    geom_vline(data = INTS, aes(xintercept = t0), color = "red") + 
    ggtitle(paste("Envelope and Speech Intervals for", basename(file_path))) +
    xlim(10, 20)
}

# Combine all intervals into a single data frame for saving
final_intervals <- do.call(rbind, all_intervals)

# Save intervals as a CSV
write.csv(final_intervals, "all_speech_activity_intervals.csv", row.names = FALSE)

# Save as RData for later steps
save(final_intervals, file = "all_speech_activity_intervals.RData")
