function [] = gen_voiceactivity_grids()


%audioPath = ['.' filesep 'Audio' filesep];

gridsPath = ['.' filesep 'Grids' filesep];

A = readtable('all_speech_activity_intervals.csv');

files = unique(A.file,'stable');

for i=1:length(files)

    Ax = A(ismember(A.file,files{i}),:);

    Ax.lab = Ax.type;

    Ax = pl_fix_tier(Ax,'gaps','gaplabel',{'sil'});

    pl_write_textgrid(Ax,strrep([gridsPath files{i}],'.wav','.TextGrid'));

end


end